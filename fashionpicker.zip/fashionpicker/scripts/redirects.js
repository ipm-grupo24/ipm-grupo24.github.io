function goToFeed() {
    window.location = "./feed.html";
}

function goToUserSettings() {
    window.location = "./user-settings.html";
}

function goToUserArea() {
    window.location = "./user-area.html";
}

function goToNewDesign() {
    window.location = "./new-design.html";
}
